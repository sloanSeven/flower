package com.example.demo;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;

@Service
public class FlowerService {

	private DataSource source;
	private final AtomicLong counter = new AtomicLong();
	public static final String url = "http://jsonplaceholder.typicode.com/posts";
	final static Logger logger = LogManager.getLogger(FlowerService.class);

	public FlowerService(DataSource source) {
		this.source = source;
	}

	public ArrayNode feed() {

		final String response = source.getFeed(url);
		final ArrayNode root = getArrayNode(response);
		modify(root);
		return root;
	}

	public ResponseFlower count() {

		final String response = source.getFeed(url);
		final ArrayNode root = getArrayNode(response);
		final Map<String, JsonNode> idMap = createMap(root);
		return new ResponseFlower(counter.incrementAndGet(), new TextNode("" + idMap.size()));

	}

	protected ArrayNode getArrayNode(String response) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode root = mapper.readTree(response);
			return (ArrayNode) root;
		} catch (IOException e) {
			logger.error(e);
		}
		return null;
	}

	protected ArrayNode modify(ArrayNode root) {
		try {
			ObjectNode node = (ObjectNode) root.get(3);
			node.set("title", new TextNode("1800Flowers"));
			node.set("body", new TextNode("1800Flowers"));

			return root;
		} catch (Exception e) {
			// FlowerException
			logger.error(e);
		}
		return null;
	}

	protected HashMap<String, JsonNode> createMap(ArrayNode root) {
		final HashMap<String, JsonNode> map = new HashMap<String, JsonNode>();
		try {
			final Iterator<JsonNode> it = root.iterator();

			while (it.hasNext()) {
				JsonNode node = it.next();
				JsonNode idNode = node.get("userId");
				if (idNode != null) {
					String id = idNode.asText();
					map.put(id, node);
				}
			}
		} catch (Exception e) {
			// FlowerException
			logger.error(e);
		}
		return map;
	}

}
