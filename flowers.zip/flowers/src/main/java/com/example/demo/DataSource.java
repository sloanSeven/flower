package com.example.demo;

public interface DataSource {

	public String getFeed(String url);

}