package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.node.ArrayNode;

@Controller
public class FlowerController {

	private FlowerService service;

	@Autowired
	public FlowerController(FlowerService service) {
		this.service = service;
	}

	@GetMapping(value = "/feed", produces = "application/json")
	@ResponseBody
	@SuppressWarnings("unused")
	public ArrayNode feed() {
		return service.feed();
	}

	@GetMapping("/count")
	@ResponseBody
	@SuppressWarnings("unused")
	public ResponseFlower count() {
		return service.count();
	}

}